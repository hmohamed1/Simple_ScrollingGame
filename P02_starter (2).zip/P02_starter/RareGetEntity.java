public class RareGetEntity extends GetEntity{
    
    //Location of image file to be drawn for a RareGetEntity
    private static final String RAREGET_IMAGE_FILE = "assets/consume.png";
    
    public RareGetEntity(){
        this(0, 0);        
    }
    
    public RareGetEntity(int x, int y){
        super(x, y, RAREGET_IMAGE_FILE);  
    }
    
    

    
}
