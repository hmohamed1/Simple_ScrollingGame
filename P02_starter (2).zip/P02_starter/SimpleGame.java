import java.awt.*;
import java.awt.event.*;
import java.security.Key;
import java.util.*;

//A Simple version of the scrolling game, featuring Avoids, Gets, and RareGets
//Players must reach a score threshold to win
//If player runs out of HP (via too many Avoid collisions) they lose
public class SimpleGame extends ScrollingGameEngine {

    // Dimensions of game window
    private static final int DEFAULT_WIDTH = 900;
    private static final int DEFAULT_HEIGHT = 600;

    // Starting PlayerEntity coordinates
    private static final int STARTING_PLAYER_X = 0;
    private static final int STARTING_PLAYER_Y = 100;

    // Score needed to win the game
    private static final int SCORE_TO_WIN = 300;

    // Maximum that the game speed can be increased to
    // (a percentage, ex: a value of 300 = 300% speed, or 3x regular speed)
    private static final int MAX_GAME_SPEED = 300;
    // Interval that the speed changes when pressing speed up/down keys
    private static final int SPEED_CHANGE = 20;

    private static final String INTRO_SPLASH_FILE = "assets/intro_screen.png";
    private static final String SPACE_BCKG = "assets/spaceBack.jpg";
    private static final String END_SCREEN = "assets/end_screen.gif";
    private static final String GAME_OVER = "assets/game_over.png";
    private static final String WIN_SCREEN = "assets/win_screen.png";
    // Key pressed to advance past the splash screen
    public static final int ADVANCE_SPLASH_KEY = KeyEvent.VK_ENTER;

    // Interval that Entities get spawned in the game window
    // ie: once every how many ticks does the game attempt to spawn new Entities
    private static final int SPAWN_INTERVAL = 45;
    private static final int END = 0;

    // A Random object for all your random number generation needs!
    public static final Random rand = new Random();

    // Player's current score
    private int score;

    // Stores a reference to game's PlayerEntity object for quick reference
    // (This PlayerEntity will also be in the displayList)
    private PlayerEntity player;

    public SimpleGame() {
        this(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }

    public SimpleGame(int gameWidth, int gameHeight) {
        super(gameWidth, gameHeight);
    }

    // Performs all of the initialization operations that need to be done before the
    // game starts
    protected void preGame() {
        setTitleText("SIMPLE SCROLLING GAME!");
        this.setBackgroundImage(INTRO_SPLASH_FILE);
        player = new PlayerEntity(STARTING_PLAYER_X, STARTING_PLAYER_Y);

    }

    // Called on each game tick
    protected void updateGame() {
        // scroll all scrollable Entities on the game board
        scrollEntities();
        // Spawn new entities only at a certain interval
        if (ticksElapsed % SPAWN_INTERVAL == 0) {
            spawnNewEntities();
            garbageCollectEntities();
        }
        setTitleText("HP: " +this.player.getHP() + ", Score: " +this.score);
        if (isGameOver() == true & player.getHP() <= 0){
            postGame();
            this.setBackgroundImage(GAME_OVER);
        }else if (this.score == SCORE_TO_WIN){
            this.setSplashImage(END_SCREEN);
            
        }
    

        

       

    }

    // Scroll all scrollable entities per their respective scroll speeds
    protected void scrollEntities() {
        for (int i = 0; i < displayList.size(); i++) {
            Entity obj = this.displayList.get(i);
            if (obj instanceof Scrollable) {
                int x = obj.getX() - (((Scrollable) obj).getScrollSpeed());
                obj.setX(x);
                if (obj instanceof Consumable && this.player.isCollidingWith(obj)){
                    handlePlayerCollision((Consumable)obj);;
                    i--;
                }
    
                
            }
        }

     
      

    }
    protected void garbageCollectEntities() {
        int num = 0;
        while (num < this.displayList.size()){
            Entity obj = this.displayList.get(num);
            if (obj.getWidth() <= 0){
                this.displayList.remove(num);
            }
            num ++;
            
            
        }

    }

    // Called whenever it has been determined that the PlayerEntity collided with a
    // consumable
    private void handlePlayerCollision(Consumable collidedWith) {
        displayList.remove(collidedWith);
        score += collidedWith.getPointsValue();
        player.modifyHP(collidedWith.getDamageValue());
    }

    // Spawn new Entities on the right edge of the game board
    private void spawnNewEntities() {
        if (getBackgroundImage() != END_SCREEN || getBackgroundImage() != WIN_SCREEN){
            if (getBackgroundImage() != INTRO_SPLASH_FILE || isPaused != false) {
                int type = rand.nextInt(10);
                int ranY = rand.nextInt(SimpleGame.DEFAULT_HEIGHT) - player.getHeight();
                int percent = type % 3;
                if (ranY >= 0) {
                    if (type > 1 & type < 5) {
                        Entity avoid1 = new AvoidEntity();
                        avoid1.setX(SimpleGame.DEFAULT_WIDTH);
                        avoid1.setY(ranY - avoid1.getHeight());
                        displayList.add(avoid1);
                    } else if (type >= 5 & type <= 8) {
                        Entity enemy = new AlienEntity();
                        enemy.setX(SimpleGame.DEFAULT_WIDTH);
                        enemy.setY(ranY + enemy.getHeight());
                        displayList.add(enemy);
                    } else {
                        if (type <= 1 || type == 9) {
                            Entity get2 = new RareGetEntity();
                            get2.setX(SimpleGame.DEFAULT_WIDTH);
                            get2.setY(ranY + get2.getHeight());
                            displayList.add(get2);

                        }

                    }

                }

            }
        }

    }

    // Called once the game is over, performs any end-of-game operations
    protected void postGame() { 
        for (int i = 0; i < displayList.size(); i++){
            this.displayList.remove(i);
        }
        

    }
 

    // Determines if the game is over or not
    // Game can be over due to either a win or lose state
    protected boolean isGameOver() {
        if (this.player.getHP() <= 0){
            return true;
        }else if (this.getBackgroundImage() == END_SCREEN){
            return true;
        }else{
            return false;
        }

        
    }

    // Reacts to a single key press on the keyboard
    protected void handleKeyPress(int key) {

       // setDebugText("Key Pressed!: " + KeyEvent.getKeyText(key));
       
        if(key == SPACE_KEY){
            if (getSplashImage() == END_SCREEN){
                this.setSplashImage(WIN_SCREEN);
                
            }
        }

        if (key == ADVANCE_SPLASH_KEY) {
            setTitleText(this.score + ": " + player.getHP());
            this.setBackgroundImage(SPACE_BCKG);
            this.setBackgroundColor(Color.black);
            displayList.add(player);
            score = this.score;
        }
        if (key == KEY_PAUSE_GAME) {
            if (isPaused == true) {
                isPaused = false;
            } else {
                isPaused = true;
            }

        }

        if (isPaused != true) {
            for (int i = 0; i < MOVEMENT_KEYS.length; i++) {
                if (player.x >= SimpleGame.STARTING_PLAYER_X) {
                    if (key == LEFT_KEY) {
                        player.x -= 7;
                    }
                }
                if (player.x <= SimpleGame.DEFAULT_WIDTH - player.getWidth()) {
                    if (key == RIGHT_KEY) {
                        player.x += 7;
                    }

                }
                if (player.y >= SimpleGame.STARTING_PLAYER_X) {
                    if (key == UP_KEY) {
                        player.y -= 7;
                    }
                }
                if (player.getY() < SimpleGame.DEFAULT_HEIGHT - player.getHeight()) {
                    if (key == DOWN_KEY) {
                        player.y += 7;
                    }
                }
            }
        }

    }

    // Handles reacting to a single mouse click in the game window
    // Won't be used in Simple Game... you could use it in Creative Game though!
    protected MouseEvent handleMouseClick(MouseEvent click) {
        if (click != null) { // ensure a mouse click occurred
            int clickX = click.getX();
            int clickY = click.getY();
            setDebugText("Click at: " + clickX + ", " + clickY);
        }
        return click;// returns the mouse event for any child classes overriding this method
    }

}
